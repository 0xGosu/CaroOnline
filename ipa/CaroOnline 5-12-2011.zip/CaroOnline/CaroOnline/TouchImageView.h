//
//  TouchImageView.h
//  CaroOnline
//
//  Created by V.Anh Tran on 13/11/2011.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TouchImageView : UIImageView { 
    CGPoint startLocation;
}

@end
